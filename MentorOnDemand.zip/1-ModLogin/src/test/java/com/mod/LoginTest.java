package com.mod;

import com.mod.entities.Login;

public class LoginTest {
	
	public Login createTestSuite() {
		return new Login();
		
	}
	
	

}
 