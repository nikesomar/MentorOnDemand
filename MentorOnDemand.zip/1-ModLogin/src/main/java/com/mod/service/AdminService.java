package com.mod.service;

import com.mod.entities.User;

public interface AdminService  {
	
	public User findUser(String user_name, String password);

}
